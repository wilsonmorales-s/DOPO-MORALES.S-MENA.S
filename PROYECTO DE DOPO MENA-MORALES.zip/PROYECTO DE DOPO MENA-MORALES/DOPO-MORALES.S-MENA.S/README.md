# DOPO-MORALES.S-MENA.S

Proyecto inicial de **Desarrollo Orientado por Objetos 2026-2** (Escuela Colombiana de Ingeniería):
simulador de la máquina tragamonedas del *Problem I – Slot Machine* (ICPC 2025).

**Autores:** Samuel Mena Serrato, Wilson Morales Sánchez

## Estructura

```
DOPO-MORALES.S-MENA.S/
├── slotMachine/          Proyecto BlueJ (código, pruebas y Javadoc en doc/)
├── diseno/
│   ├── astah/                        Diagramas en astah
│   └── ciclo4-para-pasar-a-astah/    Diagrama de clases y de secuencia del ciclo 4
├── documentos/           Documentación, pruebas de aceptación y retrospectivas
└── historial/ciclo2/     Versión del código del ciclo 2
```

## Cómo ejecutarlo

1. Abrir la carpeta `slotMachine` en BlueJ.
2. Crear una máquina con `new SlotMachine(n)` y llamar `makeVisible()`.
3. Resolverla con `SlotMachineContest.solve(n)` o verla resolverse con `SlotMachineContest.simulate(n)`.

## Ciclo 4: tipos de elementos

| Elemento | Tipos | Método |
|---|---|---|
| Ruedas | normal, lefty, rebel, lazy (propuesto) | `addWheel(type, pos)` |
| Símbolos | normal, ephemeral, shy | `addSymbol(type, pos, color)` |

## Pruebas

| Ciclo | Clases de prueba |
|---|---|
| 2 | `SlotMachineC2Test`, `SlotMachineCC2Test` |
| 3 | `SlotMachineContestTest`, `SlotMachineContestCTest` |
| 4 | `SlotMachineC4Test`, `SlotMachineCC4Test` |
